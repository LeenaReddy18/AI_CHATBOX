# Chatbot_Using_Generative_AI
GENERATIVE AI
Developed an advanced chat bot using Generative AI, Play Hat, Hugging Face, and Gradio for interactive user interactions.

– Implemented user-friendly navigation with React Router, dynamic scrolling with React Slick, and visually appealing
UI with Figma.
– Offers an interactive and engaging conversational experience for users.
– Technology Used: HTML5, CSS3, JavaScript, Bootstrap, client storage, Generative AI (Gradio, Hugging face,
PlayHT).
